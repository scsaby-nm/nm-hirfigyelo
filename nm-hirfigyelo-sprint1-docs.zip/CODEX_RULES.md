# CODEX_RULES.md – NM Hírfigyelő

## Alapszabályok

1. Ne végezz globális regex alapú kódcserét a teljes `worker.mjs` fájlon.
2. Egy módosítás csak a feladatban megjelölt függvényeket és CSS blokkokat érintheti.
3. Minden módosítás előtt készüljön backup.
4. A `worker.mjs` jelenlegi működő funkcióit nem szabad átírni indokolatlanul.
5. Új funkciót csak külön, jól körülhatárolt modulba vagy függvénybe szabad tenni.
6. D1 adatbázis változás csak új migrációs fájlban történhet.
7. Secret, API kulcs, service account adat nem kerülhet frontendbe vagy publikus JS-be.
8. A kód módosítása után kötelező syntax check.
9. Deploy csak dev Workerre menjen először.
10. Production deploy csak kézi jóváhagyás után.

## Header specifikus szabályok

- A fejlécben nem lehet `channel-logo.jpg`.
- A fejlécben nem lehet `nm-header-card`.
- A fejlécben nem lehet `nm-logo-wrap`.
- A fejléc szövege: `Nemzeti Minimumok`.
- A fejléc komponens legyen egyetlen közös render függvény.

## Tiltott megoldások

- Inline CSS-es vészjavítás végleges megoldásként.
- `Replace()` láncok teljes fájlra.
- Régi CSS-ek felett újabb `!important` réteg halmozása.
- Régi logós HTML elrejtése CSS-sel ahelyett, hogy a HTML ki lenne véve.

## Kiadási ellenőrzés

Minden Codex módosítás után legyen:

- módosított fájlok listája;
- rövid diff magyarázat;
- syntax check eredmény;
- kézi tesztlista.
