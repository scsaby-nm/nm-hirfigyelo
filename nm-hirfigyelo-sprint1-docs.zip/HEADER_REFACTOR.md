# Header Refactor Spec v0.1

## Cél

A jelenlegi logós/hero fejléc teljes lecserélése egyetlen közös, egyszerű szöveges fejlécre:

```text
Nemzeti Minimumok
```

## Jelenlegi probléma

A feltöltött kódban a fejléc nem egyetlen helyen van.

Talált előfordulások:

- `nm-hero-header`: 3
- `nm-header-card`: 5
- `channel-logo.jpg`: 9
- `renderCompactHeader()` indulása: kb. 1568 . sor
- `renderMainPage()` indulása: kb. 1296 . sor

A korábbi javítások azért nem voltak stabilak, mert csak CSS-t vagy csak egy blokkot próbáltak cserélni, miközben a fejléc több HTML- és CSS-rétegen keresztül épül fel.

## Új célállapot

Legyen egyetlen header komponens:

```js
function renderSiteHeader(options = {}) {
  const isEditor = Boolean(options.isEditor);
  const homePath = isEditor ? "/editor" : "/";
  return `<header class="nm-site-header">
    <div class="nm-site-header-inner">
      <a class="nm-site-title" href="${homePath}" aria-label="Nemzeti Minimumok főoldal">Nemzeti Minimumok</a>
      ${renderHeaderActions(options)}
    </div>
  </header>`;
}
```

Megjegyzés: a fenti csak specifikációs példa. A Codexnek a tényleges meglévő menü/action logikához kell igazítania.

## CSS célállapot

```css
.nm-site-header {
  background: #070707;
  border-bottom: 2px solid #c9152d;
  padding: 12px 10px;
  margin: 0 0 14px;
}

.nm-site-header-inner {
  max-width: 1220px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.nm-site-title {
  flex: 1;
  text-align: center;
  color: #fff;
  font-weight: 900;
  font-size: clamp(23px, 6vw, 38px);
  line-height: 1;
  text-decoration: none;
  white-space: nowrap;
}
```

## Mit kell eltávolítani a fejlécből

- `nm-hero-header`
- `nm-header-card`
- `nm-logo-wrap`
- `nm-logo`
- `nm-title-block`
- `nm-title-script`
- `nm-title-main`
- `nm-tagline`

## Amit nem szabad eltávolítani

- `channel-logo.jpg` fájl, mert favicon/OG/manifest célra még kellhet.
- Menü / admin navigáció logikája.
- Theme toggle logika.
- Auth logika.
- Push, audio, cikk, fordítás funkciók.

## Elfogadási feltételek

- Főoldalon nincs képes logó a fejlécben.
- Cikkoldalon nincs képes logó a fejlécben.
- Admin oldalon nincs képes logó a fejlécben.
- Mobilon nem látszik hero banner.
- A `channel-logo.jpg` csak meta/ikon/OG célra maradhat.
- Syntax check lefut.
- Dev deploy után főoldal, cikkoldal, editor betölt.

## Codexnek adható rövid prompt

Lásd: `CODEX_PROMPT_HEADER.md`.
