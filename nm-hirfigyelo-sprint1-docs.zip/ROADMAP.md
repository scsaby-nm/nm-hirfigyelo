# ROADMAP.md – NM Hírfigyelő

## 9.2 – Stabilizálás

Cél: a meglévő rendszer stabilizálása új nagy funkciók nélkül.

- Header refaktor
- Dokumentáció
- Codex szabályok
- Tesztlista
- Worker szerkezeti audit

## 9.3 – Hangcikk rendszer

- Google Cloud Text-to-Speech
- Cloudflare R2 audio tárolás
- Admin `Hangcikk készítése` gomb
- Audio URL mentés D1-be
- HTML audio player

## 9.4 – AI média

- Cikkkép prompt
- Reels prompt
- Közösségi poszt prompt
- Kép/videó workflow előkészítés

## 10.0 – Moduláris AI szerkesztőség

- `worker.mjs` modulokra bontása
- RSS → NM Ajánlja → CIKK1.0 → Hangcikk → Fordítás → Publikálás folyamat
- Stabil dokumentáció
- Dev/prod release folyamat
