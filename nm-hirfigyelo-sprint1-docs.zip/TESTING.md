# TESTING.md – NM Hírfigyelő tesztlista

## Kötelező ellenőrzés deploy előtt

### 1. Syntax check

```powershell
cd C:\a\b
node --check .\src\worker.mjs
```

Ha ez hibát dob, tilos deployolni.

### 2. Wrangler dry/deploy dev

```powershell
npx wrangler deploy
```

Csak dev Workerre.

### 3. Oldalteszt

Nyisd meg:

- `/`
- `/editor`
- `/prompt`
- `/hangoscikkek`
- egy saját `/nm-cikk?slug=...` oldal
- egy külső `/article?...` oldal, ha van ilyen

### 4. Header teszt

Minden oldalon ellenőrizd:

- nincs logókép a fejlécben;
- a fejlécben csak `Nemzeti Minimumok` szöveg van;
- mobilon nincs nagy piros hero banner;
- menü/admin funkció nem tűnt el;
- dark/light mód nem romlott el.

### 5. Admin teszt

- Cikk publikálás oldal betölt.
- Mentés/publikálás gomb megvan.
- Audio mezők nem tűntek el.
- Szerkesztés link működik.

### 6. API füstteszt

```powershell
Invoke-WebRequest https://nm-hirfigyelo-dev.scsaby.workers.dev/health
Invoke-WebRequest https://nm-hirfigyelo-dev.scsaby.workers.dev/api/counter
```

### 7. D1 migráció

Ha nem volt adatbázis-változás, ne fusson új migráció.

## Release döntés

Production csak akkor mehet, ha:

- syntax check OK;
- dev deploy OK;
- főoldal OK;
- editor OK;
- cikkoldal OK;
- mobil fejléc OK.
