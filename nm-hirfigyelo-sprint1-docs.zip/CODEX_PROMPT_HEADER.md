# CODEX_PROMPT_HEADER.md

Feladat: NM Hírfigyelő header refaktor a jelenlegi Cloudflare Worker projektben.

## Kontextus

A projektben a fejléc jelenleg több helyen és több CSS rétegben épül fel. A korábbi PowerShell/regex javítások hibát okoztak. Ezért most csak célzott, kézi refaktor megengedett.

## Cél

A fejlécből minden oldalon tűnjön el a logókép és a hero banner. A fejlécben csak ez a szöveg maradjon:

```text
Nemzeti Minimumok
```

## Kötelező teendők

1. Keress rá a `worker.mjs` fájlban:
   - `nm-hero-header`
   - `nm-header-card`
   - `nm-logo-wrap`
   - `channel-logo.jpg`
   - `renderCompactHeader`
   - `renderMainPage`

2. Hozz létre vagy alakíts ki egyetlen közös header render függvényt, például:
   - `renderSiteHeader(options)`

3. Minden oldal ezt használja:
   - főoldal
   - cikkoldal
   - admin/editor
   - prompt oldal
   - hangoscikkek oldal
   - publikálás oldal

4. A fejléc HTML-ben ne maradjon:
   - `img src="/channel-logo.jpg"`
   - `nm-header-card`
   - `nm-logo-wrap`
   - `nm-title-script`
   - `nm-title-main`
   - `nm-tagline`

5. A `channel-logo.jpg` fájlt ne töröld, mert OG/meta/favicon célra még kellhet.

6. Ne használj teljes fájlos regex cserét.

7. Ne rejtsd el CSS-sel a régi fejlécet. A régi fejléc HTML-jét kell kivenni.

## CSS cél

Egyszerű fekete fejléc, piros alsó vonallal:

```css
.nm-site-header {
  background: #070707;
  border-bottom: 2px solid #c9152d;
  padding: 12px 10px;
  margin: 0 0 14px;
}

.nm-site-title {
  color: #fff;
  font-weight: 900;
  font-size: clamp(23px, 6vw, 38px);
  text-decoration: none;
  white-space: nowrap;
}
```

## Tilos

- Globális `Replace()` lánc.
- Újabb `!important` réteg halmozása a régi hibás CSS fölé.
- Inline CSS végleges megoldásként.
- Más funkciók átírása.

## Teszt

Módosítás után futtasd:

```powershell
node --check .\src\worker.mjs
```

Majd dev deploy:

```powershell
npx wrangler deploy
```

Kézi teszt:
- `/`
- `/editor`
- `/prompt`
- `/hangoscikkek`
- `/editor/publish`
- legalább egy `/nm-cikk?slug=...`

## Várt eredmény

Minden oldalon egyszerű fejléc:
`Nemzeti Minimumok`

Nincs logó, nincs hero banner.
