# NM Hírfigyelő – Architecture Audit v0.1

Forrás: a feltöltött `nm-mostani-frissites-javitando.zip` csomag.

## Jelenlegi állapot röviden

A projekt egy Cloudflare Worker-alapú alkalmazás. A fő üzleti logika jelenleg egyetlen nagy `worker.mjs` fájlban van.

Mért adatok a jelenlegi fájlból:

- `worker.mjs`: 214,590 karakter, 2736 sor
- Függvények száma: 115
- Fontos útvonalak száma: 22
- `nm-hero-header` előfordulás: 3
- `nm-header-card` előfordulás: 5
- `channel-logo.jpg` előfordulás: 9

## Cloudflare konfiguráció

`wrangler.toml` alapján:

- Worker neve: `nm-hirfigyelo-dev`
- Entry point: `src/worker.mjs`
- Assets binding: `ASSETS`
- Workers AI binding: `AI`
- D1 binding: `DB`
- D1 adatbázis: `nm_hirfigyelo_db`

## Fő útvonalak

- `/`
- `/api/counter`
- `/api/editor/articles`
- `/api/editor/hidden`
- `/api/editor/push/outbox`
- `/api/push/public-key`
- `/api/push/subscribe`
- `/api/stats`
- `/api/translate`
- `/article`
- `/editor`
- `/editor/publish`
- `/go`
- `/hangoscikkek`
- `/health`
- `/manifest.webmanifest`
- `/nm-cikk`
- `/nm-image`
- `/prompt`
- `/robots.txt`
- `/sitemap.xml`
- `/sw.js`

## Fő modulcsoportok a jelenlegi workerben

### Oldal renderelők

- `renderCounterApi`
- `renderStatsApi`
- `renderPushPublicKey`
- `renderPushOutboxApi`
- `renderServiceWorker`
- `renderWebManifest`
- `renderPublishArticlePageOld`
- `renderPublishArticlePage`
- `renderNmArticlePage`
- `renderAudioBox`
- `renderAudioArticlesPage`
- `renderAudioCard`
- `renderNmArticleImage`
- `renderHomePage`
- `renderMainPage`
- `renderSiteFooter`
- `renderCompactHeader`
- `renderViewportScript`
- `renderSearchResults`
- `renderTagFilter`
- `renderQuickNews`
- `renderNmArticles`
- `renderNmFeatureCard`
- `renderRecommended`
- `renderTopNews`
- `renderCategories`
- `renderCard`
- `renderCardTags`
- `renderBadges`
- `renderArticlePage`
- `renderRelatedCard`
- `renderPromptPage`
- `renderVideoEmbed`
- `renderRobotsTxt`
- `renderSitemapXml`
- `renderHealthCheck`
- `renderNotFound`

### API és műveleti kezelők

- `renderCounterApi`
- `renderStatsApi`
- `renderPushOutboxApi`
- `handlePushSubscription`
- `handleHiddenArticlesApi`
- `handleEditorArticlesApi`
- `handleTranslationApi`
- `handleArticleRedirect`

### Adatbázis / analytics / cikkkezelés

- `safeLogEvent`
- `getStats`
- `getTopArticleViews`
- `getArticleViewCount`
- `renderCounterApi`
- `renderStatsApi`
- `getPublishedNmArticles`
- `getHiddenArticleIds`
- `rssArticleId`
- `handleHiddenArticlesApi`
- `slugifyNmArticle`
- `handleEditorArticlesApi`
- `renderPublishArticlePageOld`
- `renderPublishArticlePage`
- `renderNmArticlePage`
- `renderAudioArticlesPage`
- `renderNmArticleImage`
- `handleArticleRedirect`
- `loadBudapestWeatherOpenMeteo`
- `loadBudapestWeatherMetNo`
- `renderNmArticles`
- `getCachedGeneratedArticle`
- `storeGeneratedArticle`
- `renderArticlePage`
- `normalizeArticleImageInput`
- `formatCounter`
- `formatArticleDate`

### RSS / hírlogika

- `matchTopNews`
- `articleIdentity`
- `hashString`
- `rssArticleId`
- `loadAllItems`
- `renderTagFilter`
- `renderQuickNews`
- `renderTopNews`
- `renderCardTags`
- `scoreKeywords`
- `scoreCikk10`
- `scoreSocialImpact`
- `scoreFreshness`
- `itemAgeHours`
- `findRelatedItems`
- `generateTopicTags`
- `collectTagCounts`
- `getTag`
- `sanitizeRssSummary`
- `renderSitemapXml`

### AI / fordítás

- `handleTranslationApi`
- `getCachedTranslation`
- `storeCachedTranslation`

## Legnagyobb technikai kockázatok

1. A teljes alkalmazás egyetlen nagy fájlban van.
2. A fejléc HTML és CSS több helyen, egymást átfedve szerepel.
3. A CSS konstansok sok rétegből állnak, ezért egy új stílus könnyen felülírhat vagy visszahozhat régi elemeket.
4. A `channel-logo.jpg` nem csak favicon/OG célokra szerepel, hanem fejlécben is, ezért óvatosan kell szétválasztani.
5. A PowerShell-regex alapú globális csere magas kockázatú; a korábbi hiba is ezt igazolta.

## Ajánlott refaktor sorrend

1. Header rendszer külön komponensbe.
2. CSS rétegek leltározása és ütközések megszüntetése.
3. API kezelők külön fájlba.
4. Cikk renderelés külön fájlba.
5. Audio modul külön fájlba.
6. RSS modul külön fájlba.
7. D1 műveletek külön repository/service rétegbe.

## Fontos szabály

A következő módosításoknál nem szabad globális regex cserét használni a teljes `worker.mjs`-en. A módosítás csak az azonosított függvényekben történhet.
